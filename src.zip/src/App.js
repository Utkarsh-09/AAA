import React from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import { Container, Fab } from '@mui/material';
import UploadIcon from '@mui/icons-material/CloudUpload';
import Column from './Column';
import AudioPlayer from './AudioPlayer';
import './App.css';

function App() {
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  return (
    <div className="app">
      <Header onMenuClick={() => setDrawerOpen(true)} />
      <Sidebar open={drawerOpen} onClose={() => setDrawerOpen(false)} />
      
      <div className="columns-container">
        <Column title="Transcription" type="transcription" />
        <Column title="Summary" type="summary" />
        <Column title="Features" type="features" />
      </div>
      
      <AudioPlayer />
      {/* <Fab color="primary" aria-label="upload" className="fab">
        <UploadIcon />
      </Fab> */}
    </div>
  );
}

export default App;

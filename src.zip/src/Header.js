import React from 'react';
import { AppBar, Toolbar, Typography, IconButton } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import './Header.css';

function Header({ onMenuClick }) {
  return (
    <AppBar position="fixed" className="app-bar">
      <Toolbar className="toolbar">
        <IconButton edge="start" color="inherit" aria-label="menu" onClick={onMenuClick}>
          <MenuIcon />
        </IconButton>
        
        <Typography variant="h6" className="title">
          Speech Translation
        </Typography>
        
        <div className="spacer" /> {/* This is to take up the remaining space on the right side of the AppBar */}
      </Toolbar>
    </AppBar>
  );
}

export default Header;

import React from 'react';
import { Drawer, IconButton, List, ListItem, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import './Sidebar.css';

function Sidebar({ open, onClose }) {
  return (
    <Drawer className="drawer" variant="persistent" anchor="left" open={open}>
      <IconButton onClick={onClose}>
        <CloseIcon />
      </IconButton>
      <List className="drawer-container">
        <ListItem button>
          <Typography variant="body1">Upload File</Typography>
        </ListItem>
        {/* Map through uploaded files and create ListItem for each */}
      </List>
    </Drawer>
  );
}

export default Sidebar;

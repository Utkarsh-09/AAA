import React from 'react';
import { Typography, Button, Box, Paper } from '@mui/material';
import GetAppIcon from '@mui/icons-material/GetApp';
import './Column.css';

function Column({ title, type }) {
  return (
    <Box className="column">
      
      {/* Heading in Paper with Elevation */}
      <Paper elevation={3} className="paper-heading">
        <Typography variant="h6" className="centered-title">{title}</Typography>
      </Paper>
      
      <Box className="resizable-box">
        {title} content goes here...
      </Box>
      
      {type !== 'features' && (
        <Button startIcon={<GetAppIcon />} variant="outlined" size="small" className="feature-button">
          Download TXT
        </Button>
      )}
      
      {type === 'features' && (
        <Box className="features-buttons">
          {/* <Button variant="contained" size="small" className="feature-button">
            Diarization
          </Button>
          <Button variant="contained" size="small" className="feature-button">
            Sentiment Analysis
          </Button> */}
        </Box>
      )}
    </Box>
  );
}

export default Column;

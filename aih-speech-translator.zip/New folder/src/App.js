import React from 'react';

import './App.css';
import Columns from './Column';
import AudioPlayer from './AudioPlayer';

function App() {
  return (
    <div className="App">
     <Columns/>
     <AudioPlayer/>
    </div>
  );
}

export default App;

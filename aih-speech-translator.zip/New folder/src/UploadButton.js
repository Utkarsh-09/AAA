import React, { useState } from 'react';
import { Button, LinearProgress } from '@mui/material';

const UploadButton = () => {
  const [files, setFiles] = useState([]);
  const [uploadProgress, setUploadProgress] = useState({});

  const handleFileUpload = (event) => {
    // handle file upload logic here
  };

  return (
    <div>
      <Button variant="contained" component="label">
        Upload File
        <input type="file" multiple hidden onChange={handleFileUpload} />
      </Button>
      {files.map((file) => (
        <div key={file.name}>
          {file.name}
          <LinearProgress variant="determinate" value={uploadProgress[file.name] || 0} />
        </div>
      ))}
    </div>
  );
};

export default UploadButton;

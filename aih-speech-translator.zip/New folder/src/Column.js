import React from 'react';
import { Paper, Typography } from '@mui/material';
import UploadButton from './UploadButton';

const Columns = () => {
  return (
    <>
    <UploadButton />
    <div style={{ display: 'flex', gap: '1rem' }}>
        
      <Paper elevation={3} style={{ flex: 1, padding: '1rem', borderRadius: '8px' }}>
        <Typography variant="h6">Transcription</Typography>
        {<p>hahahah
            </p>}
        
      </Paper>
      <Paper elevation={3} style={{ flex: 1, padding: '1rem', borderRadius: '8px' }}>
        <Typography variant="h6">Summary</Typography>
        {/* Display Summary here */}
      </Paper>
      <Paper elevation={3} style={{ flex: 1, padding: '1rem', borderRadius: '8px' }}>
        <Typography variant="h6">Features</Typography>
        {/* Display Features like Diarization and Sentiment Analysis here */}
      </Paper>
    </div>
    </>
  );
};

export default Columns;

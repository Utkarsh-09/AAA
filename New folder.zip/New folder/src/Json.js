import React, { useState } from 'react';

function JSONUploader() {
  const [data, setData] = useState(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.type === 'application/json') {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            setData(JSON.parse(event.target.result));
          } catch (error) {
            console.error(error);
            alert('Invalid JSON file');
          }
        };
        reader.readAsText(file);
      } else {
        alert('Please upload a valid JSON file.');
      }
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileUpload} accept=".json" />
      {data && <div>Data: {JSON.stringify(data)}</div>}
    </div>
  );
}

export default JSONUploader;

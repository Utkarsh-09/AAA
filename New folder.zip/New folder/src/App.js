import logo from './logo.svg';
import './App.css';
import Json from 'react-json-object';
import ReactJsonViewCompare from 'react-json-view-compare';
import React, { useState, useEffect } from 'react';
import bootstrap from 'bootstrap'
import ReactTable from 'react-table';
import './index.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import navigateToComparisonPage from './Second.js';





function App () {
  var i=0;
  const [data, setData] = useState(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.type === 'application/json') {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            setData(JSON.parse(event.target.result));
          } catch (error) {
            console.error(error);
            alert('Invalid JSON file');
          }
        };
        reader.readAsText(file);
      } else {
        alert('Please upload a valid JSON file.');
      }
    }
  };

  const [data1, setData1] = useState(null);

  const handleFileUpload1 = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.type === 'application/json') {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            setData1(JSON.parse(event.target.result));
          } catch (error) {
            console.error(error);
            alert('Invalid JSON file');
          }
        };
        reader.readAsText(file);
      } else {
        alert('Please upload a valid JSON file.');
      }
    }
  };
 
  const [combinedData, setCombinedData] = useState(null);
  useEffect(() => {
    if (data && data1) {
        
        let newData = {};
        Object.keys(data).forEach(key => {
            if(Array.isArray(data[key])){
               let subData={};
               data[key].forEach(subKey => {
                  if(subKey.key && subKey.value){
                    subData[subKey.key] = {data:subKey.value, data1: data1[subKey.key] || null};
                  }
               });
               newData[key]=subData;
            }else{
              newData[key] = {
                data: data[key],
                data1: data1[key] || null
              };
            }
        });
        Object.keys(data1).forEach(key => {
            if(Array.isArray(data1[key])){
               let subData={};
               data1[key].forEach(subKey => {
                  if(subKey.key && subKey.value){
                    subData[subKey.key] = {data:null, data1:subKey.value};
                  }
               });
               newData[key]=subData;
            }else{
              if (!newData[key]) {
                newData[key] = {
                    data: null,
                    data1: data1[key]
                };
              }
            }
        });
        setCombinedData(newData);
    }
  }, [data, data1]);
  
  
  


  
const [showComparison, setShowComparison] = useState(false);

  
  


    return (
    <>
      <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images.png" alt="Logo" width="30" height="30" class="d-inline-block align-text-top"/>
      Json Comparator
    </a>
  </div>
</nav>

   
<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr' }}>
  <div style={{ gridColumn: '1 / 2', padding: '10px'}}>
  <div style={{ display: 'grid', placeItems: 'center'}}>
  <input 
    type="file" 
    onChange={handleFileUpload} 
    accept=".json" 
    style={{
      backgroundColor: "#3498db",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      color: "white",
      fontSize: "16px",
      fontWeight: "bold",
      "&:hover": {
        backgroundColor: "#2980b9",
        cursor: "pointer"
      }
    }}
    
  />
 {data ? 
  <>
    <h1>JSON1</h1>
    <p><Json data={data} /></p>
  </>
  : <h3>Upload JSON1</h3>
}

</div>
    
  </div>

  <div className="divider line" style={{gridColumn: '2 / 3', padding: '10px'}}>
  <div style={{ display: 'grid', placeItems: 'center'}}>
  <input 
    type="file" 
    onChange={handleFileUpload1} 
    accept=".json" 
    style={{
      backgroundColor: "#3498db",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      color: "white",
      fontSize: "16px",
      fontWeight: "bold",
      "&:hover": {
        backgroundColor: "#2980b9",
        cursor: "pointer"
      }
    }}
    
  />
 {data1 ? 
  <>
    <h1>JSON2</h1>
    <p><Json data={data1} /></p>
  </>
  : <h3>Upload Json2</h3>
}


</div>
  
    
  </div>
  <div style={{ gridColumn: '3 / 4', padding: '10px' }}>
   <button onClick={() => setShowComparison(!showComparison)}>
   {showComparison ? "Hide" : "Show"} Comparison
    </button>
    {showComparison && combinedData && 
  <div style={{ padding: '10px'}}>
    <h1>Comparison</h1>
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>#</th>
          <th>Key</th>
          <th>Json1</th>
          <th>Json2</th>
        </tr>
      </thead>
      <tbody>
        {Object.keys(combinedData).map((key, i) => (
          <tr>
            <td>{i+1}</td>
            <td>{key}</td>
            <td>{combinedData[key].data ? combinedData[key].data : 'null'}</td>
            <td>{combinedData[key].data1 ? combinedData[key].data1 : 'null'}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
}
</div>


</div>
    
  
    
  </>  
    );
}
export default App;


export default function ComparisonPage(combinedData) {
   


    return(
        <>
       
       <div style={{ padding: '10px'}}>
          <h1>Comparison</h1>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Key</th>
                <th>Json1</th>
                <th>Json2</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(combinedData).map((key, i) => (
                <tr>
                  <td>{i+1}</td>
                  <td>{key}</td>
                  <td>{combinedData[key].data ? combinedData[key].data : 'null'}</td>
                  <td>{combinedData[key].data1 ? combinedData[key].data1 : 'null'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        </>
    )
  }

  
import React, { useState } from 'react';
import { Form, Input } from 'semantic-ui-react';
import './PolicyNo.css';

const PolicyNo = () => {
  const [policyNumber, setPolicyNumber] = useState('');

  const handlePolicyNumberChange = (e) => {
    setPolicyNumber(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
  };

  return (
    <div className="form-container">
      <Form onSubmit={handleSubmit}>
        <Form.Field>
          <label className="input-label">Policy Number</label>
          <Input
            type="text"
            value={policyNumber}
            onChange={handlePolicyNumberChange}
            placeholder="Enter policy number"
          />
        </Form.Field>
        
      </Form>
    </div>
  );
};

export default PolicyNo;

import React from 'react';
import 'semantic-ui-css/semantic.min.css';
import './JsonUpload.css';

const JsonUpload = () => {
  const handleUpload = (event) => {
    const file = event.target.files[0];
    // Handle file upload logic here
  };

  return (
    <div className="upload-container">
      <div className="upload-section">
        <div className="ui yellow segment">
          <h4>Upload PDF</h4>
        </div>
      </div>
      <div className="upload-section">
        <label htmlFor="upload" className="ui white button">
          Upload
          <input type="file" id="upload" className="upload-input" onChange={handleUpload} accept=".pdf" />
        </label>
      </div>
    </div>
  );
};

export default JsonUpload;

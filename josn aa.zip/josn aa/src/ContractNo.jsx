import React, { useState } from 'react';
import { Form, Input } from 'semantic-ui-react';
import './ContractNo.css';

const ContractNo = () => {
  const [policyNumber, setPolicyNumber] = useState('');

  const handlePolicyNumberChange = (e) => {
    setPolicyNumber(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
  };

  return (
    <div className="form-container">
      <Form onSubmit={handleSubmit}>
        <Form.Field>
          <label className="input-label">Benefit Details</label>
          <Input
            type="text"
            value={policyNumber}
            onChange={handlePolicyNumberChange}
            placeholder="Enter Benefit Details"
          />
        </Form.Field>
        
      </Form>
    </div>
  );
};

export default ContractNo;

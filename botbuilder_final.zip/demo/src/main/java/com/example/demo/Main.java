package com.example.demo;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

// import javax.json.JsonObject;
// import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) throws IOException {
        StringBuffer output = new StringBuffer();
         ChatInitializer chatInitializer = new ChatInitializer();
         chatInitializer.initializeChat("I have provided you with a website link. now I want you to generate 2 questions from that website https://www.sunlife.ca/en/investments/rrsp/");
         String question = chatInitializer.getQuestion();
         ResponseAnswer responseAnswer = new ResponseAnswer();
        //  String prompt = "https://www.sunlife.ca/en/investments/rrsp/ I have provided you this website.  below I will provide you a question and a json format. firstly create an intent for that question in capital worlds with an _ between each word such as all the common worlds from that question is removed and only limited important worlds are there store it in intentname . Secondly generate 10 variations of that question store it in queries.  Thirdly  I want you to answer that question briefly but should be easy to understand from this website and store in response . generate all of the above in a json format that is sent below with proper indentation. \"Intents\" : [{\"IntentName\" : \"RRSP_HELP_RETIREMENT_PLANNING\",\"Queries\" :[\"\"]\"Response\" : [{\"\"}]}]here is the question -";
        String p1 = "Please create an intent, generate 10 variations of the question";
        String p2 = ", and provide a brief, easily understandable answer based on the information from the provided website, https://www.sunlife.ca/en/investments/rrsp. Please format your response in JSON format with proper indentation containing this intent , variation and answer as key. And only send that json output and nothing else";
         
        // chatInitializer.initializeChat("https://www.sunlife.ca/en/investments/rrsp/ I have provided you this website now I want you to answer these question that I am sending you below." + question);
         int i=0,c=0; 
         int l=question.length();
         
         String str = "";
         for(i=0;i<l;i++)
         {
           char a = question.charAt(i);
           str = str + a;
          if(a=='?')
          {
            System.out.println(c++);
            responseAnswer.initializeChat(""+ p1 + str + p2);
            
            str = "";
          } 
        }
        responseAnswer.storeStringArrayToFile("output.txt");
        ArrayList<String> stringArray = responseAnswer.getStringArray();
        for (String str1 : stringArray) {
            System.out.println(str1);
        }

        output = responseAnswer.getJson();
        BufferedWriter bwr = new BufferedWriter(new FileWriter(new File("C:\\Users\\admin\\Downloads\\op_uv")));
        bwr.write(output.toString());
        bwr.close();

        System.out.println(output);

       OpenAIClient chatClient = new OpenAIClient();
      chatClient.startChat();
    //   ArrayList<String> json = responseAnswer.getStringArray();
    //   ArrayList<String> stringArray = json;
    //   String filePath = "output.json";

    //   StringArrayToJsonConverter.convertToJson(stringArray, filePath);
        // try {
        //     ObjectMapper objectMapper = new ObjectMapper();
        //     Object jsonVariable = objectMapper.readValue(output, Object.class);

        //     // Now, you can use the jsonVariable as needed
        //     System.out.println(jsonVariable);
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }
      // String question = chatClient.getQuestion();
        // System.out.println(question);

        // ResponseAnswer responseAnswer = new ResponseAnswer();
        // responseAnswer.initializeChat(question + "answer the following questions in the context of that website");
         // ResponseAnswer responseProcessor = new ResponseAnswer();
        // responseProcessor.processResponse(chatClient);
    }
}

package com.example.demo;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class StringArrayToJsonConverter {
    public static void convertToJson(ArrayList<String> stringList, String filePath) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < stringList.size(); i++) {
            sb.append("\"").append(stringList.get(i)).append("\"");
            if (i < stringList.size() - 1) {
                sb.append(",");
            }
        }
        sb.append("]");

        try (FileWriter fileWriter = new FileWriter(filePath)) {
            fileWriter.write(sb.toString());
            System.out.println("JSON file created successfully.");
        } catch (IOException e) {
            System.out.println("Error occurred while creating JSON file: " + e.getMessage());
        }
    }
}

package com.example.demo;

public class JsonBuilder {
    ChatInitializer chatInitializer = new ChatInitializer();
    String question = chatInitializer.getQuestion();
}
     class Intent {
        private String intentName;
        private String[] queries;
        private Response[] response;
        public String getIntentName() {
            return intentName;
        }
        public void setIntentName(String intentName) {
            this.intentName = intentName;
        }
        public String[] getQueries() {
            return queries;
        }
        public void setQueries(String[] queries) {
            this.queries = queries;
        }
        public Response[] getResponse() {
            return response;
        }
        public void setResponse(Response[] response) {
            this.response = response;
        }
    
        
    
    class Response {
        private String lang;
        private String ResponseText;
        private String value;
        public String getLang() {
            return lang;
        }
        public void setLang(String lang) {
            this.lang = lang;
        }
        public String getResponseText() {
            return ResponseText;
        }
        public void setResponseText(String responseText) {
            ResponseText = responseText;
        }
        public String getValue() {
            return value;
        }
        public void setValue(String value) {
            this.value = value;
        }
    
        
    }

    
    
    
    
}

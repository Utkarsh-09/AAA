package com.example.demo;

import com.example.demo.api.OpenAIChatAPIClient;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;


public class ResponseAnswer {
    private OpenAIChatAPIClient chatAPIClient;
    private String json = "";
    private ArrayList<String> stringArray;
    StringBuffer sb= new StringBuffer();

public ResponseAnswer() {
    chatAPIClient = new OpenAIChatAPIClient();
    stringArray = new ArrayList<>();
}
public void storeStringArrayToFile(String filePath) {
    try (FileWriter writer = new FileWriter(filePath)) {
        for (String str1 : stringArray) {
            writer.write(str1);
            writer.write(System.lineSeparator());
        }
        System.out.println("StringArray content has been stored in the file: " + filePath);
    } catch (IOException e) {
        System.out.println("Error occurred while storing stringArray content in the file: " + filePath);
        e.printStackTrace();
    }
}



    public void initializeChat(String initialMessage) {
       
        
        ChatMessage initialChatMessage = new ChatMessage(initialMessage, "user");
        chatAPIClient.addMessage(initialChatMessage);
        chatAPIClient.processChatMessages();
        sb=sb.append(chatAPIClient.getLastGeneratedResponse()+ "hahah");
        json = json + chatAPIClient.getLastGeneratedResponse();
        stringArray.add(chatAPIClient.getLastGeneratedResponse());
        System.out.println(chatAPIClient.getLastGeneratedResponse());
        // Remember the initial message and response in ChatGPTClient
        OpenAIClient.setInitialMessage(initialChatMessage); 
        OpenAIClient.setLastResponse(chatAPIClient.getLastGeneratedResponse());
    }
    public StringBuffer getJson() {
        return sb;
    }
    public ArrayList<String> getStringArray() {
       return stringArray;
    }
}

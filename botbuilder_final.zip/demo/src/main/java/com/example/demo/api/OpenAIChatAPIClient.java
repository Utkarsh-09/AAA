package com.example.demo.api;

import com.example.demo.ChatMessage;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class OpenAIChatAPIClient {
    private static final String API_KEY = "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";
    private static final String CHAT_COMPLETIONS_ENDPOINT = "https://api.openai.com/v1/chat/completions";
    private static final String MODEL = "gpt-3.5-turbo";
    private static final String SYSTEM_MESSAGE = "Explain things like you're talking to a software professional with 2 years of experience.";

    private List<ChatMessage> chatMessages;
    private String lastGeneratedResponse;

    public OpenAIChatAPIClient() {
        chatMessages = new ArrayList<>();
    }

    public void addMessage(ChatMessage message) {
        chatMessages.add(message);
    }

    public void processChatMessages() {
        List<JSONObject> apiMessages = new ArrayList<>();
        for (ChatMessage message : chatMessages) {
            String role = message.getSender().equals("ChatGPT") ? "assistant" : "user";
            JSONObject messageObject = new JSONObject()
                    .put("role", role)
                    .put("content", message.getContent());
            apiMessages.add(messageObject);
        }

        JSONArray messagesArray = new JSONArray();
        messagesArray.put(new JSONObject()
                .put("role", "system")
                .put("content", SYSTEM_MESSAGE));
        messagesArray.putAll(apiMessages);

        JSONObject apiRequestBody = new JSONObject()
                .put("model", MODEL)
                .put("messages", messagesArray);

        HttpClient httpClient = HttpClient.newBuilder().build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(CHAT_COMPLETIONS_ENDPOINT))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(apiRequestBody.toString()))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                JSONObject responseData = new JSONObject(response.body());
                String generatedResponse = responseData.getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content");
                lastGeneratedResponse = generatedResponse;

                // Process the generated response or perform any desired action
                // ...
            } else {
                System.out.println("ChatGPT API request failed. Status code: " + response.statusCode());
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getLastGeneratedResponse() {
        return lastGeneratedResponse;
    }

    public Collection<?> getChatMessages() {
        return null;
    }

    public HttpResponse<String> sendAPIRequest(String string) {
        return null;
    }
}

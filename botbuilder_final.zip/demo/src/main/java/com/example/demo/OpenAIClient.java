package com.example.demo;

import com.example.demo.api.OpenAIChatAPIClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.http.HttpResponse;
import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONObject;



public class OpenAIClient {
    private static final Collection<?> MODEL = null;
    private static ChatMessage initialMessage;
    private static String lastResponse;
    private static Collection<?> systemMessage;
    private static String question = "abc";

   
    private OpenAIChatAPIClient chatAPIClient;

    public OpenAIClient() {
      
        chatAPIClient = new OpenAIChatAPIClient();
    }

    public static void setInitialMessage(ChatMessage message) {
        initialMessage = message;
    }

    public static void setLastResponse(String response) {
        lastResponse = response;
    }

    public void startChat() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            // System.out.println("ChatGPT: " + lastResponse);
            int c=0;

            while (true) {
                System.out.print("You: ");
                String userInput = reader.readLine();

                ChatMessage userMessage = new ChatMessage(userInput, "user");
                chatAPIClient.addMessage(initialMessage);
                chatAPIClient.addMessage(userMessage);
                chatAPIClient.processChatMessages();

                lastResponse = chatAPIClient.getLastGeneratedResponse();
              
                System.out.println("ChatGPT: " + lastResponse);
                
                
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // int i=0; 
        // int l=lastResponse.length();
        // for(i=0;i<=l;i++)
        // {
        //   char a = lastResponse.charAt(i);
        //   question = question + a;
        //   if(a=='?')
        //   {   
              
        //     JSONObject prompt = new JSONObject().put("role", "user").put("content", question);
        //     chatAPIClient.addMessage(new ChatMessage(question, "user"));
            
        //     JSONArray messagesArray = new JSONArray();
        //     messagesArray.put(OpenAIClient.systemMessage);
        //     messagesArray.put(OpenAIClient.initialMessage);
        //     messagesArray.putAll(chatAPIClient.getChatMessages());
            
        //     JSONObject apiRequestBody = new JSONObject()
        //             .put("model", OpenAIClient.MODEL)
        //             .put("messages", messagesArray);
            
        //     HttpResponse<String> response = chatAPIClient.sendAPIRequest(apiRequestBody.toString());
        //     if (response.statusCode() == 200) {
        //         JSONObject responseData = new JSONObject(response.body());
        //         String generatedResponse = responseData.getJSONArray("choices")
        //                 .getJSONObject(0)
        //                 .getJSONObject("message")
        //                 .getString("content");
            
        //         // System.out.println("ChatGPT: " + generatedResponse);
        //         chatAPIClient.addMessage(new ChatMessage(generatedResponse, "assistant"));
        //     } else {
        //         System.out.println("ChatGPT API request failed. Status code: " + response.statusCode());
        //     }
            
        //   }

        // } 
    }

    public String getLastResponse() {
        return null;
    }
    public String getQuestion() {
       return question;
    }
    

   
}

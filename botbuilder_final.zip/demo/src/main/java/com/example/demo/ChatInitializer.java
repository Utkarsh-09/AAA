package com.example.demo;

import com.example.demo.api.OpenAIChatAPIClient;

public class ChatInitializer {
    private OpenAIChatAPIClient chatAPIClient;
    private String question;

    public ChatInitializer() {
        chatAPIClient = new OpenAIChatAPIClient();
    }

    public void initializeChat(String initialMessage) {
        
        ChatMessage initialChatMessage = new ChatMessage(initialMessage, "user");
        chatAPIClient.addMessage(initialChatMessage);
        chatAPIClient.processChatMessages();
        question = chatAPIClient.getLastGeneratedResponse();
        
        

        System.out.println("ChatGPT: " + chatAPIClient.getLastGeneratedResponse());

        // Remember the initial message and response in ChatGPTClient
        OpenAIClient.setInitialMessage(initialChatMessage); 
        OpenAIClient.setLastResponse(chatAPIClient.getLastGeneratedResponse());
    }
    public String getQuestion() {
        return question;
    }
}

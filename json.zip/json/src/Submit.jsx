import { Form, Input } from 'semantic-ui-react';
export default function Submit(){

    return(
        <>
        <div style={{height: '5px',backgroundColor: 'white'}}></div>
        <Form>
        <Form.Button className="submit-button" primary type="submit">Submit</Form.Button>
        </Form>
        </>
    )

}


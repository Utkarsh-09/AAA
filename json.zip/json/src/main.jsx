import React from 'react'
import ReactDOM from 'react-dom/client'

import './index.css'
import './JsonUpload.css'
import './PolicyNo.css'
import 'semantic-ui-css/semantic.min.css';
import JsonUpload from './JsonUpload.jsx';
import PolicyNo from './PolicyNo';
import ContractNo from './ContractNo'
import JsonDisplay from './JsonDisplay'
import Submit from './Submit'



ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <JsonUpload/>
    <PolicyNo/>
    <ContractNo/>
    <Submit/>
    <JsonDisplay/>
  </React.StrictMode>,
)

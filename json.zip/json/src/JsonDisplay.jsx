import React, { useState, useEffect } from 'react';
import { Table } from 'semantic-ui-react';

const JsonDisplay = () => {
  const [jsonData, setJsonData] = useState([]);

  useEffect(() => {
    // Fetch your JSON data here or import it from a file
    const fetchData = async () => {
      try {
        const response = await fetch('./data.json');
        const data = await response.json();
        setJsonData(data);
      } catch (error) {
        console.error('Error fetching JSON data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <Table celled>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>Key</Table.HeaderCell>
          <Table.HeaderCell>Values</Table.HeaderCell>
        </Table.Row>
      </Table.Header>

      <Table.Body>
        {Object.keys(jsonData).map((key) => (
          <Table.Row key={key}>
            <Table.Cell>{key}</Table.Cell>
            <Table.Cell>{jsonData[key]}</Table.Cell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  );
};

export default JsonDisplay;
